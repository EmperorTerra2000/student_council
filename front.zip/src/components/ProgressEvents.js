function ProgressEvents(){
  return (
    <div className="progress">
      <span className=""></span>
    </div>
  );
}

export default ProgressEvents;