import "./Account.css";

function AccountCreating(){
  return (
    <h1>Находится в разработке</h1>
  );
}

export default AccountCreating;